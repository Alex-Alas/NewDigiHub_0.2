import React from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getCompanyProfile, getAvailableJourneys, getRankings, updateCompanyProfile, acquireJourney } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const CompanyDashboardPage = () => {
  const { data: companyProfile, isLoading: isLoadingProfile, error: errorProfile } = useQuery(getCompanyProfile);
  const { data: availableJourneys, isLoading: isLoadingJourneys, error: errorJourneys } = useQuery(getAvailableJourneys);
  const { data: rankings, isLoading: isLoadingRankings, error: errorRankings } = useQuery(getRankings, { category: 'all' });
  const updateCompanyProfileFn = useAction(updateCompanyProfile);
  const acquireJourneyFn = useAction(acquireJourney);

  if (isLoadingProfile || isLoadingJourneys || isLoadingRankings) return 'Loading...';
  if (errorProfile || errorJourneys || errorRankings) return 'Error: ' + (errorProfile || errorJourneys || errorRankings);

  const handleUpdateProfile = (updatedData) => {
    updateCompanyProfileFn(updatedData);
  };

  const handleAcquireJourney = (journeyId) => {
    acquireJourneyFn({ journeyId });
  };

  return (
    <div className="p-4 bg-slate-50 rounded-lg">
      <h1 className="text-2xl font-bold mb-4">Company Dashboard</h1>
      <section className="mb-8">
        <h2 className="text-xl font-semibold">Profile</h2>
        <p>Name: {companyProfile.name}</p>
        <p>Industry: {companyProfile.industry}</p>
        <p>Sector: {companyProfile.sector}</p>
        <p>Location: {companyProfile.location}</p>
        <p>Contact Info: {companyProfile.contactInfo}</p>
        <p>Score: {companyProfile.score}</p>
        <p>Level: {companyProfile.level}</p>
        <p>Achievements: {companyProfile.achievements}</p>
        <button onClick={() => handleUpdateProfile({ /* updated data */ })} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4">Edit Profile</button>
      </section>
      <section className="mb-8">
        <h2 className="text-xl font-semibold">Available Journeys</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableJourneys.map(journey => (
            <div key={journey.id} className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="font-bold">{journey.name}</h3>
              <p>{journey.description}</p>
              <p>Duration: {journey.duration} days</p>
              <p>Level: {journey.level}</p>
              <p>Price: ${journey.price}</p>
              <button onClick={() => handleAcquireJourney(journey.id)} className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4">Acquire Journey</button>
            </div>
          ))}
        </div>
      </section>
      <section className="mb-8">
        <h2 className="text-xl font-semibold">Rankings</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2">Name</th>
                <th className="py-2">Score</th>
              </tr>
            </thead>
            <tbody>
              {rankings.map((ranking, index) => (
                <tr key={index} className="text-center">
                  <td className="py-2">{ranking.name}</td>
                  <td className="py-2">{ranking.score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default CompanyDashboardPage;
