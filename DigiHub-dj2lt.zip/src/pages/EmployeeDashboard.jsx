import React from 'react';
import { useQuery, useAction, getEmployeeProfile, getAvailableJourneys, getRankings, enrollInJourney } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const EmployeeDashboardPage = () => {
  const { data: employeeProfile, isLoading: isLoadingProfile, error: errorProfile } = useQuery(getEmployeeProfile);
  const { data: availableJourneys, isLoading: isLoadingJourneys, error: errorJourneys } = useQuery(getAvailableJourneys);
  const { data: rankings, isLoading: isLoadingRankings, error: errorRankings } = useQuery(getRankings, { category: 'all' });
  const enrollInJourneyFn = useAction(enrollInJourney);

  if (isLoadingProfile || isLoadingJourneys || isLoadingRankings) return 'Loading...';
  if (errorProfile || errorJourneys || errorRankings) return 'Error loading data.';

  const handleEnroll = (journeyId) => {
    enrollInJourneyFn({ journeyId });
  };

  return (
    <div className="p-4 bg-gradient-to-b from-[#1A2B4C] to-[#054a91] text-white">
      <h1 className="text-2xl font-bold mb-4">Employee Dashboard</h1>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Profile</h2>
        <div className="bg-[#F5F5F5] p-4 rounded-lg shadow-md text-black">
          <p>Name: {employeeProfile.name}</p>
          <p>Position: {employeeProfile.position}</p>
          <p>Score: {employeeProfile.score}</p>
          <p>Level: {employeeProfile.level}</p>
          <p>Company: {employeeProfile.company.name}</p>
          <p>Achievements: {employeeProfile.achievements}</p>
        </div>
      </section>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Available Journeys</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableJourneys.map(journey => (
            <div key={journey.id} className="bg-[#F5F5F5] p-4 rounded-lg shadow-md text-black">
              <h3 className="font-bold">{journey.name}</h3>
              <p>{journey.description}</p>
              <p>Duration: {journey.duration} days</p>
              <p>Level: {journey.level}</p>
              <p>Price: ${journey.price}</p>
              <button 
                onClick={() => handleEnroll(journey.id)}
                className="mt-2 bg-[#5DB1D4] hover:bg-[#054a91] text-white font-bold py-2 px-4 rounded"
              >
                Enroll
              </button>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-xl font-semibold mb-2">Rankings</h2>
        <div className="bg-[#F5F5F5] p-4 rounded-lg shadow-md text-black">
          {rankings.map((rank, index) => (
            <div key={rank.id} className="flex justify-between border-b border-[#E0E0E0] py-2">
              <span>{index + 1}. {rank.name}</span>
              <span>Score: {rank.score}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default EmployeeDashboardPage;
